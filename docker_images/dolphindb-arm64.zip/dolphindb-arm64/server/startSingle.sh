#!/bin/sh
nohup ./dolphindb -console 0 > single.nohup 2>&1 &
