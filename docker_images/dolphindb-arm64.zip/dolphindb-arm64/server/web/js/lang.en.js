var langobj = [
    {
    "key": "CENTRAL_SERVER",
    "value": "Agent Central Server :"
},
{
    "key": "NODE_SITE",
    "value": "node site :"
},
{
    "key": "MAXCONNECTION",
    "value": "maxconnection :"
},
{
    "key": "MAXCORE",
    "value": "max cores :"
}


]